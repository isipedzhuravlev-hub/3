import random
import os
from datetime import datetime

STATS_DIR = "game_stats"
STATS_FILE = "stats.txt"


def save_result(result_text):
   
    if not os.path.exists(STATS_DIR):
        os.makedirs(STATS_DIR)

    path = os.path.join(STATS_DIR, STATS_FILE)

    with open(path, "a", encoding="utf-8") as f:
        f.write(result_text + "\n")


def print_board(board):
    size = len(board)
    print(" ", *range(1, size + 1))
    for i in range(size):
        print(i + 1, *board[i])


def check_win(board, player):
    size = len(board)


    for row in board:
        if all(cell == player for cell in row):
            return True

    for col in range(size):
        if all(board[row][col] == player for row in range(size)):
            return True

    if all(board[i][i] == player for i in range(size)):
        return True

    if all(board[i][size - 1 - i] == player for i in range(size)):
        return True

    return False

def board_full(board):
    for row in board:
        if "." in row:
            return False
    return True

def get_board_size():
    while True:
        size_input = input("Введите размер игрового поля (3-9): ")
        if not size_input.isdigit():
            print("Некорректный ввод, попробуйте снова.")
            continue
        size = int(size_input)
        if 3 <= size <= 9:
            return size
        print("Некорректный размер, попробуйте снова.")

def get_move(board, player):
    size = len(board)
    while True:
        move = input(f"Ход игрока {player}. Введите строку и столбец (например: 1 2): ")
        parts = move.split()

        if len(parts) != 2 or not parts[0].isdigit() or not parts[1].isdigit():
            print("Некорректный ввод, попробуйте снова.")
            continue

        r, c = int(parts[0]) - 1, int(parts[1]) - 1

        if not (0 <= r < size and 0 <= c < size):
            print("Выход за границы поля, попробуйте снова.")
            continue

        if board[r][c] != ".":
            print("Эта клетка уже занята, выберите другую.")
            continue

        return r, c

def play_game():
    size = get_board_size()
    board = [["." for _ in range(size)] for _ in range(size)]

    players = ["X", "O"]
    current = random.choice(players)

    print(f"\nПервым ходит: {current}\n")
    print_board(board)

    while True:
        r, c = get_move(board, current)
        board[r][c] = current

        print_board(board)

        if check_win(board, current):
            print(f"Игрок {current} победил!")

            save_result(
                f"{datetime.now()} | Поле: {size}x{size} | Победитель: {current}"
            )
            break

        if board_full(board):
            print("Ничья!")

            save_result(
                f"{datetime.now()} | Поле: {size}x{size} | Ничья"
            )
            break

        current = "O" if current == "X" else "X"

def main():
    while True:
        play_game()
        again = input("Хотите сыграть ещё раз? (y/n): ").strip().lower()
        if again != "y":
            print("До свидания!")
            break
    main()  